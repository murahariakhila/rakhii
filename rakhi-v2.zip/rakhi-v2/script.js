/* ===================== STATE ===================== */
var state = {
  brotherName: "Brother",
  senderName: "Sister",
  msg: "Every year this thread reminds us how far we've come and how much we still have each other. Thank you for always having my back. Happy Raksha Bandhan!",
  reasons: [
    "You always pick up the phone, even at odd hours.",
    "You make me laugh harder than anyone else.",
    "You've had my back since we were kids."
  ],
  photos: [],
  closing: "Stay awesome, stay you. Sending you all my love this Raksha Bandhan.",
  signoff: "\u2014 Your sister, forever in your corner \ud83d\udc9c",
  theme: "royal"
};

var themes = {
  royal:   {purple:"#6B3FA0", purpleDeep:"#3D1660", purpleMid:"#8B5FBF", gold:"#E8B34E", goldDeep:"#C9922E", lavender:"#F3EAFB", pink:"#D46FB0"},
  blush:   {purple:"#A0508F", purpleDeep:"#5C1F52", purpleMid:"#C07AB0", gold:"#F2C14E", goldDeep:"#D99B2B", lavender:"#FBEAF3", pink:"#E9789F"},
  midnight:{purple:"#4B3F91", purpleDeep:"#241455", purpleMid:"#6E5FC2", gold:"#D8B457", goldDeep:"#B4903B", lavender:"#E9E6FA", pink:"#8E6FD1"}
};

/* ===================== PAGE NAVIGATION ===================== */
var pages = Array.prototype.slice.call(document.querySelectorAll('.page'));
var currentPage = 0;

function renderDots(){
  var nav = document.getElementById('dotNav');
  nav.innerHTML = '';
  pages.forEach(function(p, i){
    var d = document.createElement('div');
    d.className = 'dot' + (i === currentPage ? ' current' : (i < currentPage ? ' done' : ''));
    nav.appendChild(d);
  });
}

function goToPage(index){
  if(index < 0 || index >= pages.length) return;
  pages[currentPage].classList.remove('active');
  currentPage = index;
  pages[currentPage].classList.add('active');
  renderDots();
  window.scrollTo(0,0);
}

/* ===================== THEME ===================== */
function applyTheme(name){
  var t = themes[name] || themes.royal;
  var root = document.documentElement.style;
  root.setProperty('--purple', t.purple);
  root.setProperty('--purple-deep', t.purpleDeep);
  root.setProperty('--purple-mid', t.purpleMid);
  root.setProperty('--gold', t.gold);
  root.setProperty('--gold-deep', t.goldDeep);
  root.setProperty('--lavender', t.lavender);
  root.setProperty('--pink', t.pink);
}

function renderThemeSwatches(){
  var row = document.getElementById('themeRow');
  row.innerHTML = '';
  Object.keys(themes).forEach(function(name){
    var sw = document.createElement('div');
    sw.className = 'swatch' + (state.theme === name ? ' active' : '');
    sw.style.background = themes[name].purple;
    sw.title = name;
    sw.onclick = function(){ state.theme = name; renderThemeSwatches(); applyTheme(name); };
    row.appendChild(sw);
  });
}

/* ===================== EFFECTS ===================== */
function launchConfetti(){
  var colors = ['#E8B34E','#6B3FA0','#D46FB0','#C9922E'];
  for(var i=0;i<40;i++){
    (function(){
      var p = document.createElement('div');
      p.className = 'confetti-piece';
      p.style.left = Math.random()*100 + 'vw';
      p.style.background = colors[Math.floor(Math.random()*colors.length)];
      p.style.transform = 'rotate('+(Math.random()*360)+'deg)';
      document.body.appendChild(p);
      var duration = 2000 + Math.random()*1500;
      var start = null;
      function step(ts){
        if(!start) start = ts;
        var elapsed = ts - start;
        var progress = elapsed / duration;
        p.style.top = (progress*110) + 'vh';
        p.style.opacity = 1 - progress;
        if(progress < 1) requestAnimationFrame(step);
        else p.remove();
      }
      requestAnimationFrame(step);
    })();
  }
}

function launchPetals(){
  var petals = ['\ud83c\udf38','\ud83c\udf3c','\ud83c\udf3a'];
  for(var i=0;i<18;i++){
    (function(){
      var p = document.createElement('div');
      p.className = 'petal';
      p.textContent = petals[Math.floor(Math.random()*petals.length)];
      p.style.left = (30 + Math.random()*40) + 'vw';
      document.body.appendChild(p);
      var duration = 1600 + Math.random()*1000;
      var start = null;
      function step(ts){
        if(!start) start = ts;
        var elapsed = ts - start;
        var progress = elapsed / duration;
        p.style.top = (progress*90) + 'vh';
        p.style.opacity = 1 - progress;
        p.style.transform = 'rotate('+(progress*220)+'deg)';
        if(progress < 1) requestAnimationFrame(step);
        else p.remove();
      }
      requestAnimationFrame(step);
    })();
  }
}

function playBell(){
  try{
    var ctx = new (window.AudioContext || window.webkitAudioContext)();
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.4);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.6);
  }catch(e){}
}

/* ===================== PAGE 1: THREAD PULL ===================== */
(function(){
  var handle = document.getElementById('threadHandle');
  var line = document.getElementById('threadLine');
  var spin = document.getElementById('rakhiSpin');
  var zone = document.getElementById('threadZone');
  var label = document.getElementById('pullLabel');
  var dragging = false, startX = 0, maxDrag = 0, threshold = 120, done = false;

  function trackWidth(){ return document.querySelector('.thread-track').offsetWidth - 60; }

  function onDown(e){
    if(done) return;
    dragging = true;
    startX = (e.touches ? e.touches[0].clientX : e.clientX);
    handle.style.cursor = 'grabbing';
  }
  function onMove(e){
    if(!dragging || done) return;
    var x = (e.touches ? e.touches[0].clientX : e.clientX);
    var delta = Math.max(0, startX - x);
    maxDrag = trackWidth();
    var pull = Math.min(delta, maxDrag);
    handle.style.transform = 'translate(-'+pull+'px,-50%)';
    line.style.transform = 'translateY(-50%) scaleX(' + (1 - pull/maxDrag*0.4) + ')';
    spin.style.transform = 'translate(-50%,-50%) rotate('+(pull*3)+'deg)';
    if(pull >= threshold && !done){
      done = true;
      zone.classList.add('completing');
      label.textContent = "Tying the thread...";
      launchPetals();
      setTimeout(function(){ goToPage(1); }, 900);
    }
  }
  function onUp(){
    dragging = false;
    if(!done){
      handle.style.transform = 'translate(0,-50%)';
      line.style.transform = 'translateY(-50%) scaleX(1)';
    }
    handle.style.cursor = 'grab';
  }

  handle.addEventListener('mousedown', onDown);
  handle.addEventListener('touchstart', onDown, {passive:true});
  window.addEventListener('mousemove', onMove);
  window.addEventListener('touchmove', onMove, {passive:true});
  window.addEventListener('mouseup', onUp);
  window.addEventListener('touchend', onUp);

  // tap fallback for accessibility
  handle.addEventListener('click', function(){
    if(done) return;
    done = true;
    zone.classList.add('completing');
    label.textContent = "Tying the thread...";
    launchPetals();
    setTimeout(function(){ goToPage(1); }, 900);
  });
})();

/* ===================== PAGE 2: ENVELOPE ===================== */
document.getElementById('openLetterBtn').addEventListener('click', function(){
  var env = document.getElementById('envelope');
  env.classList.add('opened');
  this.disabled = true;
  setTimeout(function(){ goToPage(2); }, 1300);
});

/* ===================== PAGE 3: PHOTO ALBUM ===================== */
var albumPlacedCount = 0;
var selectedChip = null;

function renderAlbumPage(){
  var slotsWrap = document.getElementById('albumSlots');
  var trayWrap = document.getElementById('photoTray');
  slotsWrap.innerHTML = '';
  trayWrap.innerHTML = '';
  albumPlacedCount = 0;
  selectedChip = null;

  var count = 3;
  for(var s=0; s<count; s++){
    var slot = document.createElement('div');
    slot.className = 'album-slot';
    slot.dataset.index = s;
    slotsWrap.appendChild(slot);
  }

  for(var i=0; i<count; i++){
    var p = state.photos[i] || {src:'', cap:''};
    var chip = document.createElement('div');
    chip.className = 'photo-chip';
    chip.dataset.index = i;
    chip.draggable = true;
    if(p.src){
      chip.innerHTML = '<img src="'+p.src+'" alt="memory">';
    } else {
      chip.innerHTML = '<div class="ph-placeholder">\ud83d\uddbc\ufe0f</div>';
    }
    trayWrap.appendChild(chip);
  }

  wireAlbumInteractions();
}

function wireAlbumInteractions(){
  var chips = document.querySelectorAll('.photo-chip');
  var slots = document.querySelectorAll('.album-slot');

  chips.forEach(function(chip){
    chip.addEventListener('dragstart', function(e){
      e.dataTransfer.setData('text/plain', chip.dataset.index);
    });
    chip.addEventListener('click', function(){
      chips.forEach(function(c){ c.classList.remove('selected'); });
      if(selectedChip === chip){ selectedChip = null; return; }
      selectedChip = chip;
      chip.classList.add('selected');
    });
  });

  slots.forEach(function(slot){
    slot.addEventListener('dragover', function(e){ e.preventDefault(); slot.classList.add('dragover'); });
    slot.addEventListener('dragleave', function(){ slot.classList.remove('dragover'); });
    slot.addEventListener('drop', function(e){
      e.preventDefault();
      slot.classList.remove('dragover');
      var idx = e.dataTransfer.getData('text/plain');
      placePhotoInSlot(idx, slot);
    });
    slot.addEventListener('click', function(){
      if(slot.classList.contains('filled')) return;
      if(selectedChip){
        placePhotoInSlot(selectedChip.dataset.index, slot);
        selectedChip = null;
      }
    });
  });
}

function placePhotoInSlot(chipIndex, slot){
  if(slot.classList.contains('filled')) return;
  var chip = document.querySelector('.photo-chip[data-index="'+chipIndex+'"]');
  if(!chip || chip.classList.contains('placed')) return;
  var p = state.photos[chipIndex] || {};
  slot.innerHTML = p.src ? '<img src="'+p.src+'" alt="memory">' : '<div class="ph-placeholder">\ud83d\uddbc\ufe0f</div>';
  slot.classList.add('filled');
  chip.classList.add('placed');
  albumPlacedCount++;
  if(albumPlacedCount >= 3){
    var instr = document.getElementById('albumInstructions');
    instr.textContent = "\u2764\ufe0f You've unlocked our memories";
    instr.classList.add('album-unlocked');
    setTimeout(function(){ goToPage(3); }, 1300);
  }
}

/* ===================== PAGE 4: FLIP CARDS + GIFT ===================== */
var flippedCount = 0;

function renderFlipCards(){
  var grid = document.getElementById('flipGrid');
  grid.innerHTML = '';
  flippedCount = 0;
  document.getElementById('giftReveal').classList.remove('show');
  document.getElementById('reasonsInstructions').style.display = 'block';

  state.reasons.forEach(function(r, i){
    var card = document.createElement('div');
    card.className = 'flip-card';
    card.innerHTML =
      '<div class="flip-inner">' +
        '<div class="flip-front">\ud83d\udc9c</div>' +
        '<div class="flip-back">'+r+'</div>' +
      '</div>';
    card.addEventListener('click', function(){
      if(this.classList.contains('flipped')) return;
      this.classList.add('flipped');
      flippedCount++;
      if(flippedCount >= state.reasons.length){
        document.getElementById('reasonsInstructions').style.display = 'none';
        document.getElementById('giftReveal').classList.add('show');
      }
    });
    grid.appendChild(card);
  });
}

document.getElementById('giftBoxReasons').addEventListener('click', function(){
  var self = this;
  self.classList.add('shake');
  setTimeout(function(){
    self.classList.add('opened');
    launchConfetti();
    setTimeout(function(){ goToPage(4); }, 700);
  }, 500);
});

/* ===================== PAGE 5: RAKHI DRAG-TO-WRIST ===================== */
(function(){
  var drag = document.getElementById('rakhiDrag');
  var dropZone = document.getElementById('wristDrop');
  var tied = document.getElementById('rakhiTied');
  var success = document.getElementById('tieSuccess');
  var continueBtn = document.getElementById('continueAfterTie');
  var dragging = false, offsetX = 0, offsetY = 0, isTied = false;

  function getPoint(e){ return e.touches ? e.touches[0] : e; }

  function onDown(e){
    if(isTied) return;
    dragging = true;
    var pt = getPoint(e);
    var rect = drag.getBoundingClientRect();
    offsetX = pt.clientX - rect.left;
    offsetY = pt.clientY - rect.top;
    drag.style.position = 'fixed';
    drag.style.zIndex = 999;
  }
  function onMove(e){
    if(!dragging || isTied) return;
    var pt = getPoint(e);
    drag.style.left = (pt.clientX - offsetX) + 'px';
    drag.style.top = (pt.clientY - offsetY) + 'px';
    drag.style.transform = 'none';
  }
  function onUp(e){
    if(!dragging || isTied) return;
    dragging = false;
    var dragRect = drag.getBoundingClientRect();
    var dropRect = dropZone.getBoundingClientRect();
    var overlap = !(dragRect.right < dropRect.left || dragRect.left > dropRect.right ||
                     dragRect.bottom < dropRect.top || dragRect.top > dropRect.bottom);
    if(overlap){
      completeTying();
    } else {
      drag.style.position = 'absolute';
      drag.style.left = '50%'; drag.style.top = '0';
      drag.style.transform = 'translate(-50%,0)';
    }
  }

  function completeTying(){
    isTied = true;
    drag.classList.add('hidden');
    tied.classList.add('tied');
    launchPetals();
    playBell();
    success.classList.add('show');
    continueBtn.classList.remove('hidden');
  }

  drag.addEventListener('mousedown', onDown);
  drag.addEventListener('touchstart', onDown, {passive:true});
  window.addEventListener('mousemove', onMove);
  window.addEventListener('touchmove', onMove, {passive:false});
  window.addEventListener('mouseup', onUp);
  window.addEventListener('touchend', onUp);

  // tap fallback
  drag.addEventListener('click', function(){
    if(isTied || dragging) return;
    completeTying();
  });

  continueBtn.addEventListener('click', function(){ goToPage(5); });
})();

/* ===================== PAGE 6: FINAL GIFT ===================== */
document.getElementById('giftBoxFinal').addEventListener('click', function(){
  var self = this;
  if(self.classList.contains('opened')) return;
  self.classList.add('shake');
  setTimeout(function(){
    self.classList.add('opened');
    launchConfetti();
    document.getElementById('tapHint').style.display = 'none';
    document.getElementById('closingMessageWrap').classList.remove('hidden');
  }, 500);
});

document.getElementById('copyWishBtn').addEventListener('click', function(){
  var text = document.getElementById('closingText').textContent;
  if(navigator.clipboard){ navigator.clipboard.writeText(text); }
  alert('Copied the wish! Paste it wherever you like.');
});

document.getElementById('restartBtn').addEventListener('click', function(){
  location.reload();
});

/* ===================== CUSTOMIZE PANEL ===================== */
function renderReasonInputs(){
  var wrap = document.getElementById('reasonInputs');
  wrap.innerHTML = '';
  state.reasons.forEach(function(r, i){
    var row = document.createElement('div');
    row.className = 'reason-row';
    row.innerHTML = '<input type="text" data-i="'+i+'" value="'+r.replace(/"/g,'&quot;')+'"><button data-i="'+i+'" title="Remove">\u2715</button>';
    wrap.appendChild(row);
  });
  wrap.querySelectorAll('input').forEach(function(inp){
    inp.oninput = function(){ state.reasons[+inp.dataset.i] = inp.value; };
  });
  wrap.querySelectorAll('button').forEach(function(btn){
    btn.onclick = function(){ state.reasons.splice(+btn.dataset.i,1); renderReasonInputs(); };
  });
}

function renderPhotoInputs(){
  var wrap = document.getElementById('photoInputs');
  wrap.innerHTML = '';
  state.photos.forEach(function(p, i){
    var row = document.createElement('div');
    row.className = 'photo-row';
    row.innerHTML =
      '<div class="row-top">' +
        '<input type="file" accept="image/*" data-i="'+i+'" style="flex:1;">' +
        '<button data-del="'+i+'">\u2715</button>' +
      '</div>' +
      '<input type="text" data-cap="'+i+'" placeholder="Caption (optional)" value="'+(p.cap||'').replace(/"/g,'&quot;')+'">';
    wrap.appendChild(row);
  });
  wrap.querySelectorAll('input[type=file]').forEach(function(inp){
    inp.onchange = function(e){
      var i = +inp.dataset.i;
      var file = e.target.files[0];
      if(!file) return;
      var reader = new FileReader();
      reader.onload = function(ev){ state.photos[i].src = ev.target.result; };
      reader.readAsDataURL(file);
    };
  });
  wrap.querySelectorAll('input[data-cap]').forEach(function(inp){
    inp.oninput = function(){ state.photos[+inp.dataset.cap].cap = inp.value; };
  });
  wrap.querySelectorAll('button[data-del]').forEach(function(btn){
    btn.onclick = function(){ state.photos.splice(+btn.dataset.del,1); renderPhotoInputs(); };
  });
}

document.getElementById('addReason').onclick = function(){
  state.reasons.push('New reason...');
  renderReasonInputs();
};
document.getElementById('addPhoto').onclick = function(){
  if(state.photos.length >= 3){ alert('The album has 3 slots — remove one first.'); return; }
  state.photos.push({src:'', cap:''});
  renderPhotoInputs();
};

function renderPreview(){
  document.getElementById('brotherNameHero').textContent = state.brotherName || 'Brother';
  document.getElementById('senderNameHero').textContent = state.senderName || 'Sister';
  document.getElementById('msgText').textContent = state.msg;
  document.getElementById('closingText').textContent = state.closing;
  document.getElementById('signOff').textContent = state.signoff;
  renderFlipCards();
  renderAlbumPage();
}

document.getElementById('applyBtn').onclick = function(){
  state.brotherName = document.getElementById('in_brotherName').value.trim();
  state.senderName = document.getElementById('in_senderName').value.trim();
  state.msg = document.getElementById('in_msg').value.trim();
  state.closing = document.getElementById('in_closing').value.trim();
  state.signoff = document.getElementById('in_signoff').value.trim();
  renderPreview();
  document.getElementById('editPanel').classList.remove('open');
};

document.getElementById('editToggle').onclick = function(){
  document.getElementById('editPanel').classList.toggle('open');
};

document.getElementById('downloadBtn').onclick = function(){
  document.getElementById('editToggle').style.display = 'none';
  document.getElementById('editPanel').style.display = 'none';
  var html = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
  var blob = new Blob([html], {type:'text/html'});
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = (state.brotherName || 'rakhi') + '-raksha-bandhan.html';
  a.click();
  URL.revokeObjectURL(url);
  document.getElementById('editToggle').style.display = 'block';
  document.getElementById('editPanel').style.display = 'block';
};

/* ===================== INIT ===================== */
renderDots();
renderThemeSwatches();
renderReasonInputs();
renderPhotoInputs();
renderPreview();

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(function(){});
}
